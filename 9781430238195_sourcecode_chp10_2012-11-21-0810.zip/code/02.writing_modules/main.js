var Hamster = require("./hamster");
var animal = new Hamster();
animal.sayHello();